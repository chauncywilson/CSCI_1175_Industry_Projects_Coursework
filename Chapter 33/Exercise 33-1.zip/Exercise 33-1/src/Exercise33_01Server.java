// Exercise31_01Server.java: The server can communicate with
// multiple clients concurrently using the multiple threads
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class Exercise33_01Server extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();
  private Calendar date = new GregorianCalendar();
  private Loan loan = new Loan();

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) throws IOException {
    ta.setWrapText(true);

    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 400, 200);
    primaryStage.setTitle("Exercise31_01Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    new Thread(() -> {
      try {
        //create a serverSocket
        ServerSocket serverSocket = new ServerSocket(8000);
        Platform.runLater(() -> ta.appendText("Exercise33_01Server started at " + date.getTime() + "\n"));

        //listen for a connection request
        Socket socket = serverSocket.accept();

        Platform.runLater(() -> ta.appendText("Connected to a client " + date.getTime() + "\n"));

        //Create a data input and output streams
        DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());

        while (true) {
          double annualInterestRate = inputFromClient.readDouble();
          int numberOfYears = inputFromClient.readInt();
          double loanAmount = inputFromClient.readDouble();

          setLoanValues(annualInterestRate, numberOfYears, loanAmount);

          double monthlyPayment = calculateMonthlyPayment();
          double totalPayment = calculateTotalPayment();

          outputToClient.writeDouble(monthlyPayment);
          outputToClient.writeDouble(totalPayment);
          outputToClient.flush();


          Platform.runLater(() -> {
            ta.appendText("Received from client at " + date.getTime() + "\n"
            + "Annual Interest Rate: " + loan.getAnnualInterestRate() + "\n"
            + "Number of Years: " + loan.getNumberOfYears() + "\n"
            + "Loan Amount: " + loan.getLoanAmount() + "\n"
            + "Monthly Payment: " + monthlyPayment + "\n"
            + "Total Payment: " + totalPayment + "\n");
          });
        }

      } catch (IOException e) {
        e.printStackTrace();
      }
    }).start();
  }

  public void setLoanValues(double annualInterestRate, int numberOfYears, double loanAmount) {
    loan.setAnnualInterestRate(annualInterestRate);
    loan.setNumberOfYears(numberOfYears);
    loan.setLoanAmount(loanAmount);
  }

  public double calculateMonthlyPayment() {
    double payment = loan.getMonthlyPayment();
    ta.appendText("Monthly Payment: " + payment);
    return payment;
  }

  public double calculateTotalPayment() {
    double payment = loan.getTotalPayment();
    ta.appendText("Total Payment: " + payment);
    return payment;
  }

    
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
