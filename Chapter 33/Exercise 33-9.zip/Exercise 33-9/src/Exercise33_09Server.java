import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Exercise33_09Server extends Application {
  private TextArea taServer = new TextArea();
  private TextArea taClient = new TextArea();
 
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) throws IOException {
    taServer.setWrapText(true);
    taServer.setEditable(false);

    taClient.setEditable(true);
    taClient.setWrapText(true);
    //taServer.setDisable(true);

    BorderPane pane1 = new BorderPane();
    pane1.setTop(new Label("History"));
    pane1.setCenter(new ScrollPane(taServer));
    BorderPane pane2 = new BorderPane();
    pane2.setTop(new Label("New Message"));
    pane2.setCenter(new ScrollPane(taClient));

    
    VBox vBox = new VBox(5);
    vBox.getChildren().addAll(pane1, pane2);

    // Create a scene and place it in the stage
    Scene scene = new Scene(vBox, 200, 200);
    primaryStage.setTitle("Exercise31_09Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    // To complete later

    new Thread(() -> {
      try {
        ServerSocket serverSocket = new ServerSocket(8000);
        Platform.runLater(() ->
                taServer.appendText("Server started at " + new Date() + "\n"));

        Socket socket = serverSocket.accept();
        Platform.runLater(() ->
                taServer.appendText("Connected to client at " + new Date() + "\n"));

        DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());

        //read from client
        while (true) {
          String line = inputFromClient.readLine();

          Platform.runLater(() -> {
            taServer.appendText("c: " + line + "\n");
          });

          //write to the client

            taClient.setOnKeyPressed(e -> {
              try {
              if (e.getCode() == KeyCode.ENTER) {
                String lineOut = taClient.getText();
                System.out.println("line grabbed");
                try {
                  outputToClient.writeChars(lineOut);
                  outputToClient.flush();

                  taServer.appendText("s: " + lineOut + "\n");
                  taClient.clear();
                  System.out.println("line sent and appended to server history");
                } catch (IOException ex) {
                  ex.printStackTrace();
                  }
                }
              } catch (Exception ex) {
                ex.printStackTrace();
              }
            });
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }).start();
    //send to client
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
