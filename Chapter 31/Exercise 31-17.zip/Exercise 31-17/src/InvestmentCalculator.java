/*
Chauncy Wilson, Industry Projects

2/16/23, Investment calculator
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;

import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class InvestmentCalculator extends Application {
    TextField textField1 = new TextField();
    TextField textField2 = new TextField();
    TextField textField3 = new TextField();
    TextField textField4 = new TextField();

    Label invAmount = new Label("Investment Amount:");
    Label numOfYears = new Label("Number of Years:");
    Label anIntRate = new Label("Annual Interest Rate:");
    Label futureValue = new Label("Future Value:");

    MenuBar menuBar = new MenuBar();
    Button button = new Button("Calculate");

    @Override
    public void start(Stage primaryStage) {
        setVisualAreas();

        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(15));

        pane.add(menuBar, 0, 0);
        pane.add(invAmount, 0, 1);
        pane.add(numOfYears, 0, 2);
        pane.add(anIntRate, 0, 3);
        pane.add(futureValue, 0, 4);

        pane.add(textField1, 1, 1);
        pane.add(textField2, 1, 2);
        pane.add(textField3, 1, 3);
        pane.add(textField4, 1, 4);

        pane.add(button, 1, 5);

        button.setOnAction(new CalculateHandler());


        Scene scene = new Scene(pane, 400, 200);
        primaryStage.setTitle("Exercise 31-17");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setVisualAreas() {
        invAmount.setPadding(new Insets(5));
        numOfYears.setPadding(new Insets(5));
        anIntRate.setPadding(new Insets(5));
        futureValue.setPadding(new Insets(5));

        textField1.setAlignment(Pos.CENTER_RIGHT);
        textField2.setAlignment(Pos.CENTER_RIGHT);
        textField3.setAlignment(Pos.CENTER_RIGHT);
        textField4.setAlignment(Pos.CENTER_RIGHT);

        textField4.setEditable(false);

        Menu menuOperation = new Menu("Operation");
        menuBar.getMenus().add(menuOperation);

        MenuItem itemCalculate = new MenuItem("Calculate");
        MenuItem itemExit = new MenuItem("Exit");

        menuOperation.getItems().addAll(itemCalculate, itemExit);
        itemCalculate.setOnAction(new CalculateHandler());
        itemExit.setOnAction(event -> System.exit(1));
    }

    class CalculateHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            String investmentAmountString = textField1.getText();
            double investmentAmount = Double.parseDouble(investmentAmountString);

            String numberOfYearsString = textField2.getText();
            int numberOfYears = Integer.parseInt(numberOfYearsString);

            String monthlyInterestRateString = textField3.getText();
            double monthlyInterestRate = Double.parseDouble(monthlyInterestRateString);
            monthlyInterestRate /= 1200;

            double futureValue = investmentAmount * Math.pow((1 + monthlyInterestRate), numberOfYears * 12);

            textField4.setText(String.format("$%.2f", futureValue));
        }
    }


    public static void main(String[] args) {
        launch();
    }
}
